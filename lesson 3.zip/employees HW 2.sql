use employees;
SELECT e.emp_no, concat(e.first_name, ' ', e.last_name) as name, max(s.salary)
	FROM employees e
    join
		salaries s
        on e.emp_no = s.emp_no
	group by e.emp_no
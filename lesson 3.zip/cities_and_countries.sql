select city.id, city.important, city.title, regi.title as region_title, country.title as country_title
	from 
		_cities as city
		join
		_regions as regi
        on city.region_id = regi.id
        join
        _countries as country
        on city.country_id = country.id
        limit 1000;
        
select city.id, city.important, city.title, regi.title as region_title, country.title as country_title
	from 
		_cities as city
		join
		_regions as regi
        on city.region_id = regi.id
        join
        _countries as country
        on city.country_id = country.id
        where regi.title like 'Московская область'
        limit 1000;
use employess;
SELECT dept_name, avg(s.salary)
	FROM 
		departments d
    join
		dept_emp de
        on d.dept_no = de.dept_no
    join
		salaries s
		on de.emp_no = s.emp_no
	where s.to_date like '9999-01-01'
    group by d.dept_no;
    

use employees;
DELETE FROM employees
	where emp_no = (
		select emp_no 
        from salaries s
		order by s.salary desc
		limit 1
    )
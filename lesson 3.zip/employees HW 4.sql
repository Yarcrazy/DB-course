use employess;
SELECT dept_name, count(emp_no) as emp
	FROM 
		departments d
    join
		dept_emp de
        on d.dept_no = de.dept_no
	where de.to_date like '9999-01-01'
    group by d.dept_name;
    

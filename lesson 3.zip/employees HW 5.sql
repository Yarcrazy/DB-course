use employess;
SELECT dept_name, count(de.emp_no) as emp, sum(s.salary) as sum
	FROM 
		departments d
    join
		dept_emp de
        on d.dept_no = de.dept_no
	join
		salaries s
        on de.emp_no = s.emp_no
	where de.to_date like '9999-01-01'
    group by d.dept_name;
    
